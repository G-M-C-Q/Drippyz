﻿using Drippyz.Data.Base;
using Drippyz.Models;

namespace Drippyz.Data.Services
{
    //pass store model 
    public interface IStoresService:IEntityBaseRepository<Store>
    {
    }
}
