﻿namespace Drippyz.Data.Base
{
    public interface IEntityBase
    {
        //define id 

        int Id { get; set; }    

    }
}
