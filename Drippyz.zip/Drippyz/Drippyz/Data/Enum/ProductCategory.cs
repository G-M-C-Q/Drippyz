﻿namespace Drippyz.Data
{
    public enum ProductCategory
    {
        Pint = 1,
        Minipint,
        Bar
    }
}
