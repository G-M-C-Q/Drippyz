﻿using Drippyz.Data.Cart;

namespace Drippyz.Data.ViewModels
{
    public class ShoppingCartVM
    {
        public ShoppingCart ShoppingCart { get; set; }
        public double ShoppingCartTotal { get; set; }

        
    }
}
