﻿
namespace Drippyz.Models
{
    internal class keyAttribute : Attribute
    {
    }
}